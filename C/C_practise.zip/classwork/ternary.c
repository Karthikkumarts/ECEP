/*#include<stdio.h>
int main()
{
    int num1=10,num2=20,num3;
    num3= num1 > num2 ? num1 : num2;
    printf("greater num is %d",num3);
    return 0;
}*/

#include<stdio.h>
/*int main()
{
    int num1=10,num2=20,num3;
     num1 > num2 ? (num3 =num1): (num3 = num2) ;
    printf("greater num is %d",num3);
    return 0;
}*/

#include<stdio.h>
int main()
{
    int num1=10,num2=20,num3;
   num3= num1 > num2 ? num1 : num2;
    printf("greater num is %d",num3);
    return 0;
}

#include<stdio.h>
enum bool
{
//e_false,
e_true,
e_false
};
int main()
{
//printf("%d\n", e_false);
printf("%d\n", e_true);
printf("%d\n", e_false);
return 0;
}

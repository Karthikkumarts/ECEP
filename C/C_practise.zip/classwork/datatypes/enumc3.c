#include<stdio.h>
int main()
{
    typedef enum
    {
	red,
	blue
    }colour;
    int bl;
    printf("%d\n",blue);
    printf("%d\n",bl);
}


#include<stdio.h>
typedef enum 
{
    e_red=1,
    e_blue=1,
    e_green
} color;
int main()
{
    color e_white=0,e_black;
    printf("%d\n",e_red);
    printf("%d\n",e_blue);
    printf("%d\n",e_green);
}

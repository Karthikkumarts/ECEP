/*#include<stdio.h>
typedef int array_of_100[100];
int main()
{
    array_of_100 array;
    printf("%zu\n",sizeof(array));
}*/

typedef int* int_ptr;
typedef float* float_ptr;
int main()
{
    int_ptr ptr1,ptr2,ptr3;
    float_ptr fptr;
    return 0;
}


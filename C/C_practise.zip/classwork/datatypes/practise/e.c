#include<stdio.h>
int main()
{

    signed char ch =126;
    printf("%d",ch);
}

#include<stdio.h>
int main ()
{
    signed char x = -1;
    unsigned char y=-5;
    printf("%d %d\n",x,y);
    signed char b=129;
    unsigned char v= 256;
    printf("%d %d\n",b,v);
    signed char k=-129;
    unsigned char a= 257;
    printf("%d %d\n",k,a);

}

#include<stdio.h>
int main()
{
    char x='A';
    char y =65;
    printf("%d %c\n",x,y);
    printf("%c %d\n",x,y);
}


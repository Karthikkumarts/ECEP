#include<stdio.h>
#include<stdlib.h>
int kar(const void *a,const void *b)
{
    return *(int *)a  < *(int *)b; 
}
int main()
{
    int size;
    printf("enter the size : ");
    scanf("%d",&size);
    int arr[size];
    printf("enter the elements : ");
    for(int i = 0 ; i < size ; i++)
    scanf("%d",&arr[i]);
    qsort(arr,size,sizeof(int),kar);
    for(int i = 0 ; i < size ; i++)
    printf("%d ",arr[i]);
}

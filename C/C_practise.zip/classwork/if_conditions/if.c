#include<stdio.h>
int main()
{
    int num = 2;
    if (num < 5)
    {    
	printf("num < 5\n");
    }
    printf("num is %d\n",num);
return 0;
}

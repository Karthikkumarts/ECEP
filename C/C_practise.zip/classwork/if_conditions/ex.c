#include<stdio.h>
int main()
{
    signed char x = -10;
    if(x)
    {
	printf("hello\n");
    }
    else
    {
	printf("world\n");
    }
}

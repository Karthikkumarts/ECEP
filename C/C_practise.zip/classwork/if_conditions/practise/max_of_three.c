#include<stdio.h>
int main()
{
    int n1,n2,n3;
    printf("enter the values:");
    scanf("%d %d %d",&n1,&n2,&n3);
    if(n1 > n2 && n1 > n3)
    {
	printf("n1 is greater\n");
    }
    else if(n2 > n1 && n2 > n3 )
    {
	printf("n2 greater\n");
    }
    else
    {
	printf("n3 is greater\n");
    }
}

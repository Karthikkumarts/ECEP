#include<stdio.h>
int main()
{
    int num;
    printf("enter the number: ");
    scanf("%d",&num);
    if((num % 2) == 0)
    {
	printf("num is even\n");
    }
    else
    {
	printf("num is odd\n");
    }
}

#include<stdio.h>
int main()
{
    int num;
    printf("enter the number:");
    scanf("%d",&num);
    if(num > 0)
    {
	printf("num is positive\n");
    }
    else
    {
	printf("num is negative\n");
    }

}

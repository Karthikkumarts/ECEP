#include<stdio.h>
int main()
{
    int *ptr;
    int *ptr1;
    int *ptr2;
    printf("ptr = %d\n",*ptr);
    printf("ptr1 = %d\n",*ptr1);
    printf("ptr2 = %d\n",*ptr2);
    return 0;
}

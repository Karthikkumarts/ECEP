#include<stdio.h>
int main()
{
    char str[10];
    puts("enter the string");
    fgets(str,10,stdin);
    puts(str);
    return 0;
}

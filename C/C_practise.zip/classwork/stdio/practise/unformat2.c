#include<stdio.h>
int main()
{
    char ch;
    ch = getc(stdin);
    putc(ch,stdout);
}

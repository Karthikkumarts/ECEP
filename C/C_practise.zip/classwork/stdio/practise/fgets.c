#include<stdio.h>
int main()
{
    char ch[5];
    printf("enter the string : ");
   fgets(ch,5,stdin);
    puts(ch);
}

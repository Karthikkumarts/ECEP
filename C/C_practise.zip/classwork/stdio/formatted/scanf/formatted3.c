#include<stdio.h>
int main()
 {
     int min,hour,sec;
    scanf("%d  %d %d",&hour,&min,&sec);
    printf("%d hour %d min %d sec",hour,min,sec);
}

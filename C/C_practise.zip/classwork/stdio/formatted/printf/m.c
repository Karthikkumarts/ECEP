#include<stdio.h>
int main()
{
    printf("%d",printf("%d",printf("%d",123)));
}

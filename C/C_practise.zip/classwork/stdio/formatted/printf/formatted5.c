#include<stdio.h>
int main()
{
    printf("100% \b score\n" );
    printf("100%%score\n");
}

#include<stdio.h>
int main()
{
    printf(5+"hello world"); //this will prints after character
}

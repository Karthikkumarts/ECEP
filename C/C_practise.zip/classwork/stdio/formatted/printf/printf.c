#include<stdio.h>
int main()
{
    printf("%c,%f,%d",126,67,25); //logical mistake,based on format specifier that many arguments must be passed
}

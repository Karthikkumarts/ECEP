#include<stdio.h>
int main()
{
    char a[ ]="emertxe";
    printf("size of a is %zu\n",sizeof(a));
    printf("%s",a);
}

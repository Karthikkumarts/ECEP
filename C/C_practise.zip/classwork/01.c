#include<stdio.h>
int main()
{
    int option='A';
    int age=23;
    float height=5.2;
    printf("the character is %c \n",option);
    printf("the integer is %d \n",age);
    printf("the float is %f \n",height);
return 0 ;
}

#include <stdio.h>
int main()
{
    int option;
     float f;
    scanf("%d %f",&option,&f);
    printf("the value is %d\n the value of float is  %f\n",option,f);
    return 0;
}

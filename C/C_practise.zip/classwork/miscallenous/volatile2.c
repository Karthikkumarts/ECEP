#include<stdio.h>
int main()
{
    unsigned int i=0xFFFFFFFF;
    int num;
    for(int i=0;i<FFFFFFFF;i--)
    {
	num=5;

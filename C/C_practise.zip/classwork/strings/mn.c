#include<stdio.h>
#include<string.h>
void main()
{
    char exp[50]="karthik";
    printf("%C",strrev(exp));
}

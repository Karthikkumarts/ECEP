#include<stdio.h>
#include<string.h>
int main()
{
    char src[20]="karthik";
    char dest[10]="kumar";
    strcat(src,dest);
    printf("%s",src);
}

#include<stdio.h>
#include<string.h>
int main()
{
    char ch[200]="karthik";
    char ch1[10]="  kumar";
    strcat(ch , ch1);
    printf("%s",ch);
}


#include<stdio.h>
int main()
{
    char ch[6];
    scanf("%2s",ch);
    printf("%s",ch);
}

#include<stdio.h>
int main()
{
    char *ch="karthik";
    printf("%s\n",ch);
    ch[5]='M';
    printf("%s\n",ch);

}

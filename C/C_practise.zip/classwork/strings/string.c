#include<stdio.h>
int main()
{
    char str[6]={'H','E','L','L','O'};
    printf("%s\n",str);


    char str2[6]={'H','E','L','L','O','\0'};
    printf("%s\n",str2);

//   	char str3[6]={"H","E","L","L","O",'\0'}
  //  printf("%s",str3}; 


    char str4[6]= { "H" "E" "L" "L" "O" "\0"};
printf("%s\n",str4);

char str5[6]={"hello"};
printf("%s\n",str5);

char str6[6]="hello";
printf("%s\n",str6);

}

#include<stdio.h>
#include<string.h>
//example for empty string
int main()
{
    char *str="";
    int ret;
    ret = strlen(str);
    printf("%d",ret);
    return 0;
}

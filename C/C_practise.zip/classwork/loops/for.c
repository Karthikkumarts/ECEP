#include<stdio.h>
int main ()
{
    int i=0; //can be deleted this line
    for(i=0 ;i<5;i++ )
    {
	printf ("loop %d times\n",i);
    }
    printf("i---->%d\n",i);
    return 0;
}


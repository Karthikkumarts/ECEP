#include<stdio.h>
int main()
{
   int  var=5;
	while (var)
	{
	    printf(" looped %d times\n",var);
	  var--;
	}
	printf("var----> %d\n",var);
	return 0;
}


#include<stdio.h>
int main()
{
    char ch = 1;
    for(signed char i = 0 ; i  < 256 ; i++)
    {
	printf("%d\n",ch++);
    }
}
	

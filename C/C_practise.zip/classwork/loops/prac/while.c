#include<stdio.h>
int main()
{
    char ch=1;

    while(ch)
    {
	printf("%d\n",ch);
	ch++;
    }
}

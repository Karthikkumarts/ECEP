#include<stdio.h>
int main()
{
   int  var=0;
	while (var < 5)
	{
	    printf(" looped %d times\n",var);
	    var=var+1; //can use only var++ 
	}
	return 0;
}


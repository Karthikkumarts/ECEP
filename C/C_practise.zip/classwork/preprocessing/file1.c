int num;
#include<stdio.h>
#include"file3.h"
int main()
{
    puts(test());
    return 0;
}

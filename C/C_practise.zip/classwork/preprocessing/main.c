#include<stdio.h>
#include"header.h"
int main()
{
int num1=6,num2=4;
printf("%d\n",sum(num1,num2));
printf("%d\n",sub(num1,num2));
return 0;
}


char *test(void)
{
    static char *str="hello";
    return str;
}

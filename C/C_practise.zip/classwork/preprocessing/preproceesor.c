#include<stdio.h>

//thie is main function
int main()
{
    printf("hello world\n");
    return 0;
}

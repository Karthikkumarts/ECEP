#include<stdio.h>
#define PI 3.142

int main()
{
    float pi=3.142;
    printf("value of pi = %f\n",pi);
    printf("value of PI = %f\n",PI);
   // PI=2.93 //error
    return 0;
}

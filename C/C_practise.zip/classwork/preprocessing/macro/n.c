#include<stdio.h>
#define sum(c,d) c##d

int main()
{
    int a=3,b=5,mul;
	printf("%d",sum(a,b));
}

#include<stdio.h>
int main()
{
//#line 100 "project tuntun"
printf("This is from file %s at line %d \n", __FILE__ ,__LINE__);
}

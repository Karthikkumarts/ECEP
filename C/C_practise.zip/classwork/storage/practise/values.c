#include<stdio.h>
int a=100;
int b =5;

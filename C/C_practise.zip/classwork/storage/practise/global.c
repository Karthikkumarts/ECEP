#include<stdio.h>
int x=10;
int main()
{
    {
    int x=20;
    printf("%d",x);
    }
    printf("%d",x);
}

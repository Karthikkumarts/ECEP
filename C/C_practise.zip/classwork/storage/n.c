#include<stdio.h>
int main()
{
    int a;
    a=5,4;
    int b=(3,2);
    printf("%d %d",a,b);
}

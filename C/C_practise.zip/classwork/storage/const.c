#include<stdio.h>
int main()
{
     int arr[6]={10,20,30,40,50};
    for (int i =0;i<5;i++)
    {
printf("%d",arr[i]);
    }
    /*int x=10;
    const y = x;
    printf("%d %d",x,y);*/
}

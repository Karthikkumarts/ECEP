int x=10;

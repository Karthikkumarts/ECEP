/*description : this file contains global variable max*/
#include<stdio.h>
int max= 10;


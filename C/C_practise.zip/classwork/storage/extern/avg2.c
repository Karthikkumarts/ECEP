#include<stdio.h>
double average(int num1,int num2)
{
   return ( num1 + num2 ) / 2.0;
}

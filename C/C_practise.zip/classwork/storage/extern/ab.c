int a=10;
int b=20;

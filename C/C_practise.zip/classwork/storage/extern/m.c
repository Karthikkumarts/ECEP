extern int add(int num1,int num2);
#include<stdio.h>
int main()
{
    int sum=add(12,20);
    printf("%d",sum);
}

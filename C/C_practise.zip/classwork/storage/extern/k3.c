#include<stdio.h>
int average (int num1,int num2)
{
    int a = (num1+num2)/2;
    return a;

}

extern double average(int num1,int num2);
#include<stdio.h>
int main()
{
    double avg = average(10,10);
    printf("average = %f\n",avg);
    return 0;
}


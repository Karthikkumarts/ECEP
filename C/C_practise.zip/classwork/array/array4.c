#include<stdio.h>
int main()
{
    int arr[ ]={0};
    for(int i=0;i<1;i++)
    {
     printf("the size of array is %d",arr[i]);
    }
    return 0;
}

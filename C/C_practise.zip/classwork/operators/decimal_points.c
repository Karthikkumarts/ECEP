#include<stdio.h>
int main()
{
    int a=5,b=0;
    float c=10.45623987456;
	printf("%.3d %.2f",a,c);
}

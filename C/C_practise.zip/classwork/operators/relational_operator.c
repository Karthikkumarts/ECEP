#include<stdio.h>
int main()
{
float num1 = 0.7;
if (num1 == 0.7) //converting 0.7(double) to float add f to 0.7
{
printf("Yes, it is equal\n");
}
else
{
printf("No, it is not equal\n");
}
return 0;
}

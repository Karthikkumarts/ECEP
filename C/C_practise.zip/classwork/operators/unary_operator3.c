/*#include<stdio.h>
int main()
{
    int x=5,y,z;
    y=x++;
    z=y;
    printf("x=%d y=%d z=%d",x,y,z);
    return 0;
}*/


 #include<stdio.h>
int main()
{
    int x=5,y,z;
    y=++x;
    z=y;
    printf("x=%d y=%d z=%d",x,y,z);
    return 0;
}

#include<stdio.h>
int main()
{
     float  num1=1;
    if (num1 = 1) //here it is not comparing, it is assigning.....assign !1,0,0=num1,num ==1
	printf("yes,its is equal!!\n");
    else
	printf("no,it is not  equal\n");
    return 0;
}



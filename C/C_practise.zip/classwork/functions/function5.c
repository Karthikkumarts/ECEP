#include<stdio.h>
void print(void);
void print(void)
{
    printf("hello world");
}
int  main()
{
    print( );
    return 0;
}

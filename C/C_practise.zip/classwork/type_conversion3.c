#include<stdio.h>
int main()
{
   unsigned char a=-1;
    char b=10;
    if(a > b )
	printf("yes\n");
    else
	printf("no");
    printf("%d",a);
}
